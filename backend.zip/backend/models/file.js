// const mongoose = require('mongoose');
// const Schema = mongoose.Schema;
//
// const fileSchema = new Schema({
// 	ownerId: { type: Schema.Types.ObjectId, ref: 'Owner', required: true },
// 	armyId: { type: String, required: true },
// 	fileName: { type: String, required: true },
// 	fileUrl: { type: String, required: true },
// 	uploadDate: { type: Date, default: Date.now }
// });
//
// module.exports = mongoose.model('File', fileSchema);
// // unused